import 'package:flutter/material.dart';
import 'package:form_builder_example/common_widgets/common_text.dart';
import 'package:form_builder_example/core/objects/drop_down_item.dart';

class CommonDropDown extends StatefulWidget {
  final List<DropDownItem> itemList;

  const CommonDropDown({super.key, required this.itemList});

  @override
  State<CommonDropDown> createState() => _CommonDropDownState();
}

class _CommonDropDownState extends State<CommonDropDown> {
  late List<DropDownItem> dropDownList;
  late DropDownItem _selectedItem;

  @override
  void initState() {
    super.initState();
    dropDownList = widget.itemList;
    _selectedItem = dropDownList[0]; // Default selection
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(4.0),
      ),
      child: DropdownButton<String>(
        isExpanded: true,
        value: _selectedItem.itemTitle,
        onChanged: (String? newValue) {
          setState(() {
            _selectedItem =
                dropDownList.firstWhere((item) => item.itemTitle == newValue);
          });
        },
        underline: Container(), // remove underline
        items: dropDownList.map((item) {
          return DropdownMenuItem<String>(
            value: item.itemTitle,
            child: Row(
              children: [
                Icon(item.itemIcon, size: 20),
                const SizedBox(width: 10.0),
                CommonText(textTitle: item.itemTitle,),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
