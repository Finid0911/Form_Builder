import 'package:flutter/material.dart';
import 'package:form_builder_example/common_widgets/common_drop_down.dart';
import 'package:form_builder_example/common_widgets/common_multiple_choice.dart';
import 'package:form_builder_example/common_widgets/common_text_field.dart';
import 'package:form_builder_example/common_widgets/custom_line.dart';
import 'package:form_builder_example/core/objects/drop_down_item.dart';
import 'package:form_builder_example/utilities/constants.dart';

class CommonInputField extends StatefulWidget {
  final String inputType;
  final List<DropDownItem> dropDownList;

  const CommonInputField(
      {super.key, required this.inputType, required this.dropDownList});

  @override
  State<CommonInputField> createState() => _CommonInputFieldState();
}

class _CommonInputFieldState extends State<CommonInputField> {
  late String _currentInputType;
  late List<DropDownItem> _dropDownList;
  final List<String> options = ["Option A", "Option B", "Option C"];
  String selectedOption = "";

  void updateSelectedOption(String newValue) {
    setState(() {
      selectedOption = newValue;
    });
  }

  @override
  void initState() {
    super.initState();
    _currentInputType = widget.inputType;
    _dropDownList = widget.dropDownList;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 10.0),
                child: CommonTextField(
                  textLabel: "Question",
                  backgroundColor: Color.fromARGB(255, 239, 241, 239),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Flexible(
                      flex: 2,
                      child: Icon(Icons.image_outlined,
                          size: 30, color: Colors.grey)),
                  Flexible(
                      flex: 8, child: CommonDropDown(itemList: _dropDownList)),
                ],
              ),
              switch (_currentInputType) {
                paragraph => const CommonTextField(
                    textLabel: "Long answer text",
                  ),
                multipleChoice => CommonMultipleChoice(
                    options: options,
                    selectedOption: selectedOption,
                    onSelectionChanged: updateSelectedOption,
                  ),
                String() => throw UnimplementedError(),
              },
              const Padding(
                padding: EdgeInsets.only(top: 50.0, bottom: 10.0),
                child: CustomLine(
                  opacity: 0.3,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                      onPressed: () => {},
                      icon: const Icon(Icons.edit_outlined)),
                  IconButton(
                      onPressed: () => {},
                      icon: const Icon(Icons.delete_rounded))
                ],
              )
            ],
          ),
        ));
  }
}
