import 'package:flutter/material.dart';
import 'package:form_builder_example/core/objects/drop_down_item.dart';
import 'package:form_builder_example/utilities/constants.dart';

class MyFormState {
  List<DropDownItem> dropDownList;
  String selectedDropDownItem;

  static final List<DropDownItem> _defaultDropDownList = [
    DropDownItem(itemIcon: Icons.article_outlined, itemTitle: "Paragraph"),
    DropDownItem(
        itemIcon: Icons.radio_button_checked, itemTitle: "Multiple Choice"),
  ];

  MyFormState(
      {List<DropDownItem>? dropDownList, this.selectedDropDownItem = paragraph})
      : dropDownList = dropDownList ?? _defaultDropDownList;
}
