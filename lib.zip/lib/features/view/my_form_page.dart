import 'package:flutter/material.dart';
import 'package:form_builder_example/common_widgets/common_input_field.dart';
import 'package:form_builder_example/common_widgets/common_text.dart';
import 'package:form_builder_example/utilities/constants.dart';

class MyFormPage extends StatelessWidget {
  const MyFormPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color.fromARGB(255, 248, 212, 241),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(6.0),
            child: _FormTitleSection(),
          ),
          const Padding(
            padding: EdgeInsets.all(6.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 10.0),
                  child: CommonInputField(
                    inputType: paragraph,
                    dropDownList: [],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FormTitleSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 10.0,
            decoration: const BoxDecoration(
              color: Colors.deepPurple,
              borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 20.0, left: 10.0, right: 10.0),
            child: CommonText(
              textTitle: "Untitled form",
              textSize: 26.0,
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(
                top: 20.0, bottom: 20.0, left: 10.0, right: 10.0),
            child: CommonText(
              textTitle: "Form description",
            ),
          )
        ],
      ),
    );
  }
}
