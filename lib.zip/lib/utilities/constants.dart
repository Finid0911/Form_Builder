const paragraph = "Paragraph";
const multipleChoice = "Multiple choice";
